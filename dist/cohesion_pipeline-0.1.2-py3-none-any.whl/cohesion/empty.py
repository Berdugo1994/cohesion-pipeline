def printMe():
    print("HEy")